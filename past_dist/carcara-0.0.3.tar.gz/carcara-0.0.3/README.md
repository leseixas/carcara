<h1 align="center" style="margin-top:20px; margin-bottom:50px;">
<img src="https://raw.githubusercontent.com/leseixas/carcara/refs/heads/main/logo/logo_light.png" style="height: 100px"></h1>

[![License: MIT](https://img.shields.io/github/license/leseixas/carcara?color=green&style=for-the-badge)](LICENSE)    [![PyPI](https://img.shields.io/pypi/v/carcara?color=red&style=for-the-badge)](https://pypi.org/project/carcara/)

# Carcará

# Installation

# Usage

# License




